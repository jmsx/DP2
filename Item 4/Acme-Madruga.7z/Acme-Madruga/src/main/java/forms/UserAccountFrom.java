
package forms;

import domain.DomainEntity;

public class UserAccountFrom extends DomainEntity {

}
